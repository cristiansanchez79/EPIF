<head>
    <title>Whipped Cream -> Postres</title>
    <link rel="stylesheet" href="css/main.css">
  </head>
  <body>
  <div id="drag-container">
  <div id="spin-container">
  
    <!-- Add your images (or video) here -->
    <img src="img/fresa.jpg" alt="">
    <img src="img/whipped2.gif" alt="">
    <img src="img/tresleches.jpg" alt="">
    <img src="img/limon.jpg" alt="">
    <img src="img/maracu.jpg" alt="">
    <img src="img/chocolate.jpg" alt="">
    <img src="img/coco.jpg" alt="">
    <img src="img/galleta.jpg" alt="">
    <img src="img/oreo.jpg" alt="">
    
    <!-- Example image with link -->
    
 

    

    <!-- Text at center of ground -->
    <p>Whipped Cream</p>
  </div>
    <?
  include 'menu.php';
 ?>
  <div id="ground"></div>
    
</div>

<div id="container"></div>










  <script src="js/seo.js" theme="dark" position="bottom-right"></script>
  
 </body>
</html>