<?php
session_start();
session_destroy();
print("<br><br> <p class='btn btn-info tbn-xl'><center><img src='img/postresito.gif' classs'loo'  width='40%'></center><center><em><b><h2>Session finalizada</h2></b></em></center></p>");
print("<meta http-equiv='refresh' content='2;url=index.php'>");

?>
   