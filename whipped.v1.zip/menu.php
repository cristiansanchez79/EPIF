<head>
<link rel="stylesheet" href="css/min.css">
</head>
<body>
<div class="contenedor">
  <div class="contenedor__label">
    <label for="btn__label" class="btn__label">
      <span></span>
      <span></span>
      <span></span>
    </label>
  </div>

  <input type="checkbox" id="btn__label">
  <ul class="menu">
    <li>
      <a href="salir.php">Inicio<i class='bx bx-home-alt'></i></a>
    </li>
    <li>
      <a href="galeria.php">Productos<i class='bx bx-basket'></i></a>
    </li>
    <li>
      <a href="contacto.php">Contacto<i class='bx bxs-contact'></i></a>
    </li>
    <li>
      <a href="salir.php">Salir<i class='bx bx-home-alt'></i></a>
    </li>
  </ul>
</div>
</body>